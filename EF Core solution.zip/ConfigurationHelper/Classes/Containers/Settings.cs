﻿namespace $safeprojectname$.Classes.Containers
{
    public class Settings
    {
        public string Environment { get; set; }

        public override string ToString() => Environment;

    }
}

